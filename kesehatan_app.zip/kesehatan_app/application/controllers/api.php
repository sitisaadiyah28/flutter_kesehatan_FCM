<?php
	
	defined('BASEPATH') OR exit ('No Script Direct');

	class Api extends CI_Controller{

		function __construct(){
			parent::__construct();
			date_default_timezone_set('Asia/Jakarta');
			error_reporting(E_ALL);
			ini_set('Display Error', 1);
		}

		function getInfoKesehatan(){
			$idKesehatan = $this->input->post('idkesehatan');
			$this->db->where('id_kesehatan', $idKesehatan);
   		 	$query = $this->db->get('tb_kesehatan');
			//$query = $this->db->get('tb_news');
			if($idKesehatan != null || $idKesehatan != ""){
				if($query -> num_rows() > 0){
					$data['message'] = "Successfully Get Data News With Id";
					$data['status'] = 200;
					$data['kesehatan'] = $query->result();
				}else{
					$data['message'] = "Failed Get Data News";
					$data['status'] = 400;
				}
			} else {
				 $q = $this->db->get('tb_kesehatan');
				 if($q -> num_rows() > 0){
					$data['message'] = "Successfully Get Data News Without Id";
					$data['status'] = 200;
					$data['kesehatan'] = $q->result();
				}else{
					$data['message'] = "Failed Get Data News";
					$data['status'] = 400;
				}

			}
			echo json_encode($data);
		}

		function addInfoKesehatan(){
			$title = $this->input->post('judul');
			$deskripsi = $this->input->post('deskripsi');
			$config['upload_path'] = './images/'; // tipe string dan file
			$config['allowed_types'] = 'gif|jpg|png|jpeg';

			$this->load->library('upload', $config); // ini proses untuk memasukkan ke dalam libraries

			if(! $this->upload->do_upload('image')){
				$error = array('error' => $this->upload->display_errors());
				$data1 = array(
					'message' => $error,
					'status' => 404,
				);
			}else{
				$data = array('upload_data' => $this->upload->data()); //proses upload
				$save['judul'] = $title;
				$save['deskripsi'] = $deskripsi;
				$save['image'] = $data['upload_data']['file_name']; //ini proses untuk menyimpan ke databasenya
				$query = $this->db->insert('tb_kesehatan', $save);

				//Output Request
				$data1 = array(
					'message' => "Successfully Upload News",
					'status' => 200,
					'data' => $data['upload_data']['file_name'],
				);
			}
			echo json_encode($data1);
		}

		


		function deleteInfo(){
			$idKesehatan = $this->input->post('idkesehatan');
			$this->db->where('id_kesehatan', $idKesehatan);

			$status = $this->db->delete('tb_kesehatan');
			if ($status == true){
				$data['message'] = "Successfully delete info";
				$data['status'] = 200;
			}else {
				$data['message'] = "Failed delete info";
				$data['status'] = 404;
			}
			echo json_encode($data);
		}

		function updateInfoKesehatan(){
			$idKesehatan = $this->input->post('idkesehatan');
			$judul = $this->input->post('judul');
			$deskripsi = $this->input->post('deskripsi');
			$config['upload_path'] = './images/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg';


			$this->load->library('upload', $config);
			$this->db->where('id_kesehatan', $idKesehatan);


			if(! $this->upload->do_upload('image')){
				$save['judul'] = $judul;
				$save['deskripsi'] = $deskripsi;
				$query = $this->db->update('tb_kesehatan', $save);
				$data1 = array(
					'message' => "Successfully Upload Info Without Image",
					'status' => 200,
				);
			} else {
				// Upload to folder
				$data = array('upload_data' => $this->upload->data());  

				// Upload to database
				$save['judul'] = $judul;
				$save['deskripsi'] = $deskripsi;
				$save['image'] = $data['upload_data']['file_name'];
				$query = $this->db->update('tb_kesehatan', $save);

				// Ouput Request
				$data1 = array(
					'message' => "Successfully Upload Info",
					'status' => 200,
					'data' => $data['upload_data']['file_name'],
				);

			}

			echo json_encode($data1);

		}

	}

?>